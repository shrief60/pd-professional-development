$('#editor').summernote({
    tabsize: 2,
    height: 100
});
