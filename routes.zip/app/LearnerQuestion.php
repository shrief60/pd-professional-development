<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LearnerQuestion extends Model
{

    protected $table = 'learner_question';

    protected $guarded = [];
}
