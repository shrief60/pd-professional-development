<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

        public function courses() {
        return $this->belongsToMany(Course::class);
    }

    public function posts() {
        return $this->hasMany(Post::class, 'owner');
    }
    
    public function comments() {
        return $this->hasMany(Comment::class, 'owner');
    }

    public function replies() {
        return $this->hasMany(Reply::class);
    }


    public function questions() {
        return $this->hasMany(Question::class);
    }


}
