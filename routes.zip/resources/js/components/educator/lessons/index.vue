<template>
    <div>
        Videos Index
    </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>

</style>
