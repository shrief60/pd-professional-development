<template>
    <div>
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Question...">
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>

</style>
