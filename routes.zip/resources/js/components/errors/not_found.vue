<template>
    <div>
        <h1> Not found </h1>
    </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>

</style>
