<template>
  <p>This is the homepage</p>
</template>

<script>
    export default {

    }
</script>

<style scoped>

</style>
