@extends('layouts.main')

@section('content')
<div class="container">

</div>
@endsection
