@extends('layouts.main')

@section('content')

<h1> Create </h1>

<example-component />

@stop