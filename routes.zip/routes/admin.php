<?php

Route::get('/', function () {
    dump('Hello Admin');
})->name('home');

